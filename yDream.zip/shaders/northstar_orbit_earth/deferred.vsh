#version 120
#extension GL_ARB_shader_texture_lod : enable
#define NORTHSTAR_ORBIT_RADIUS 1.0
#define NORTHSTAR_ORBIT_EARTH

#define NORTHSTAR_ORBIT
#define NO_CLOUDY_SKY
#define DEFERRED_SHADER

#include "/common/deferred_vertex.glsl"
