#version 120
#extension GL_ARB_shader_texture_lod : enable

#define NORTHSTAR_MOON
#define PREPARE_SHADER
#define NO_SHADOWS

#include "/common/prepare_vertex.glsl"
