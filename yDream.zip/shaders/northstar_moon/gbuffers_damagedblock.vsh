#version 120
#extension GL_ARB_shader_texture_lod : enable
#define NORTHSTAR_MOON

#define NO_SHADOWS
#define GBUFFER_DAMAGE

#include "/common/damage_vertex.glsl"
