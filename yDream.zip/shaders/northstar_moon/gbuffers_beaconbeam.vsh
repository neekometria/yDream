#version 120
#extension GL_ARB_shader_texture_lod : enable
#define NORTHSTAR_MOON

#define GBUFFER_BEACONBEAM

#include "/common/solid_blocks_vertex.glsl"
