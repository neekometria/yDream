#version 120
#extension GL_ARB_shader_texture_lod : enable
#define NORTHSTAR_MOON

#define COMPOSITE2_SHADER

#include "/common/composite2_vertex.glsl"
