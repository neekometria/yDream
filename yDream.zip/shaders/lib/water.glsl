float linearizeDepth(float depth) {
    return gbufferProjection[3][2] / (gbufferProjection[2][2] + 2.0 * depth - 1.0);
}

vec3 fastRaymarch(vec3 direction, vec3 hitPoint, inout float infinite, float dither) {
    vec3 pathIncrement;
    vec3 currentMarchPoint = hitPoint;
    vec3 oldMarchPoint;
    float screenDepth;
    float depthDifference = 1.0;
    vec3 screenMarchPos = camera_to_screen(hitPoint);
    float prevScreenDepth = screenMarchPos.z;
    float hitPointDepth = screenMarchPos.z;
    bool searchFlag = false;
    bool hiddenFlag = false;
    bool firstHidden = true;
    bool outOfEyeFlag = false;
    bool toFar = false;
    vec3 lastScreenMarchPos;

    int no_hidden_steps = 0;
    bool hiddens = false;

    for (int i = 0; i < RAYMARCH_STEPS; i++) {
        if (searchFlag) {
            pathIncrement *= 0.5;
            currentMarchPoint += pathIncrement * sign(depthDifference);
        } else {
            oldMarchPoint = currentMarchPoint;
            currentMarchPoint = hitPoint + ((direction * exp2(i + dither)) - direction);
            pathIncrement = currentMarchPoint - oldMarchPoint;
        }

        lastScreenMarchPos = screenMarchPos;
        screenMarchPos = camera_to_screen(currentMarchPoint);

        if (
            screenMarchPos.x < 0.0 ||
            screenMarchPos.x > 1.0 ||
            screenMarchPos.y < 0.0 ||
            screenMarchPos.y > 1.0 ||
            screenMarchPos.z < 0.0
        ) {
            outOfEyeFlag = true;
        }

        if (screenMarchPos.z > 0.9999) {
            toFar = true;
        }

        screenDepth = texture2D(depthtex1, screenMarchPos.xy).x;
        depthDifference = screenDepth - screenMarchPos.z;

        if (depthDifference < 0.0 && abs(screenDepth - prevScreenDepth) > abs(screenMarchPos.z - lastScreenMarchPos.z)) {
            hiddenFlag = true;
            hiddens = true;
            if (firstHidden) {
                firstHidden = false;
            }
        } else if (depthDifference > 0.0) {
            hiddenFlag = false;
            if (!hiddens) {
                no_hidden_steps++;
            }
        }

        if (searchFlag == false && depthDifference < 0.0 && hiddenFlag == false) {
            searchFlag = true;
        }

        prevScreenDepth = screenDepth;
    }

    infinite = float(screenDepth > 0.9999);

    if (outOfEyeFlag) {
        infinite = 1.0;
        return screenMarchPos;
    } else if (toFar) {
        if (screenDepth > 0.9999) {
            infinite = 1.0;
            return screenMarchPos;
        } else if (no_hidden_steps < 3 || screenDepth > hitPointDepth) {
            return screenMarchPos;
        } else {
            infinite = 1.0;
            return vec3(1.0);
        }
    } else {
        return screenMarchPos;
    }
}

#if SUN_REFLECTION == 1
    #if !defined NETHER && !defined THE_END
        float sun_reflection(vec3 reflectedDir) {
            vec3 astroDir = normalize(mix(moonPosition, sunPosition, step(0.5, dayNightMix)));
            float alignment = clamp(dot(normalize(reflectedDir), astroDir), 0.0, 1.0);
            float astroElevation = dot(astroDir, upVector);
            float astroFade = smoothstep(-0.02, 0.10, astroElevation);
            float lowAstro = 1.0 - smoothstep(0.05, 0.40, astroElevation);

            float core = pow(alignment, 700.0);
            float body = pow(alignment, 70.0);
            float sheen = pow(alignment, 14.0);
            float glint = core * 2.4 * (1.0 - 0.45 * lowAstro) + body * 0.28 * (1.0 + 0.5 * lowAstro) + sheen * 0.05 * lowAstro;

            #if YDREAM_GLITTER == 1
                vec2 glitterPos = worldposition.xz * 1.7 + vec2(frameTimeCounter * 0.11, frameTimeCounter * -0.07);
                vec2 noiseA = texture2D(noisetex, glitterPos * 0.21).rg;
                vec2 noiseB = texture2D(noisetex, glitterPos.yx * 0.33 - frameTimeCounter * 0.02).rg;
                float sparkle = smoothstep(0.62, 0.95, noiseA.r * noiseB.g * 1.9);
                glint *= 0.55 + sparkle * 1.6;
            #endif

            return glint * SUN_GLINT_STRENGTH * astroFade * (1.0 - rainStrength);
        }
    #endif
#endif

vec3 normal_waves(vec3 pos) {
    float speed = frameTimeCounter * .025;
    vec2 wave_1 =
        texture2D(noisetex, ((pos.xy - pos.z * 0.2) * 0.05) + vec2(speed, speed)).rg;
    wave_1 = wave_1 - .5;
    vec2 wave_2 =
        texture2D(noisetex, ((pos.xy - pos.z * 0.2) * 0.03125) - speed).rg;
    wave_2 = wave_2 - .5;
    vec2 wave_3 =
        texture2D(noisetex, ((pos.xy - pos.z * 0.2) * 0.125) + vec2(speed, -speed)).rg;
    wave_3 = wave_3 - .5;
    wave_3 *= 0.66 * (1.0 - smoothstep(18.0, 95.0, gl_FogFragCoord));

    vec2 partialWave = wave_1 + wave_2 + wave_3;

    #ifndef VANILLA_WATER
        vec2 wave_4 =
            texture2D(noisetex, ((pos.xy - pos.z * 0.2) * 0.34) + vec2(-speed * 2.3, speed * 1.7)).rg;
        wave_4 = (wave_4 - .5) * 0.35 * (1.0 - smoothstep(24.0, 110.0, gl_FogFragCoord));
        partialWave += wave_4;
    #endif

    partialWave *= mix(1.0, 0.22, smoothstep(28.0, 170.0, gl_FogFragCoord));

    vec3 finalWave = vec3(partialWave, WATER_TURBULENCE - (rainStrength * 0.6 * WATER_TURBULENCE * visibleSky));

    return normalize(finalWave);
}

vec3 refraction(vec3 fragpos, vec3 color, vec3 refraction) {
    vec2 pos = gl_FragCoord.xy * vec2(pixelSizeX, pixelSizeY);

    #if REFRACTION == 1
        pos = pos + refraction.xy * (0.075 / (1.0 + length(fragpos) * 0.4));
    #endif

    float water_absortion;
    float waterThickness = 0.0;

    #if YDREAM_FOAM == 1
        float foam = 0.0;
    #endif

    if (isEyeInWater == 0) {
        float water_distance = linearizeDepth(gl_FragCoord.z);
        float earth_depth = texture2D(depthtex1, pos.xy).r;
        float earth_distance = linearizeDepth(earth_depth);

        #if defined DISTANT_HORIZONS
            float earth_distance_dh = texture2D(dhDepthTex1, pos.xy).r;
            earth_distance_dh =
                2.0 * dhNearPlane * dhFarPlane / (dhFarPlane + dhNearPlane - (2.0 * earth_distance_dh - 1.0) * (dhFarPlane - dhNearPlane));
            earth_distance = min(earth_distance, earth_distance_dh);
        #endif

        waterThickness = max(earth_distance - water_distance, 0.0);
        water_absortion = waterThickness * waterThickness;
        water_absortion = (1.0 / -((water_absortion * WATER_ABSORPTION) + 1.125)) + 1.0;

        #if YDREAM_FOAM == 1
            vec2 foamPos = worldposition.xz * 0.9 + vec2(frameTimeCounter * 0.06, frameTimeCounter * -0.04);
            float foamBase = texture2D(noisetex, foamPos * 0.11).r * 0.6 + texture2D(noisetex, foamPos.yx * 0.23).g * 0.4;
            float foamStreak = texture2D(noisetex, foamPos * 0.55 + vec2(frameTimeCounter * 0.12, 0.0)).r * 0.6 +
                texture2D(noisetex, foamPos.yx * 0.85 - vec2(0.0, frameTimeCounter * 0.09)).g * 0.4;
            float shoreDistance = waterThickness + (foamBase - 0.5) * 0.7;
            float foamShape = (1.0 - smoothstep(0.05, 0.42, shoreDistance));
            float foamDetail = smoothstep(0.32, 0.82, foamStreak);
            foam = foamShape * mix(0.35, 1.0, foamDetail) * (0.55 + 0.45 * foamBase);
            foam *= 1.0 - smoothstep(0.0, 0.02, 0.0 - waterThickness);
        #endif
    } else {
        water_absortion = 0.0;
    }

    float depthBlend = 1.0 - exp(-waterThickness * 0.12);
    vec3 shallowColor = color * vec3(0.95, 1.50, 1.32);
    vec3 bodyColor = mix(color, mix(shallowColor, color, depthBlend), clamp(YDREAM_WATER_DEPTH_TINT, 0.0, 1.5));

    vec3 floorColor = texture2D(gaux1, pos.xy).rgb * underwaterTransmission(water_absortion * 0.85);
    vec3 refractedColor = mix(floorColor, bodyColor, water_absortion);

    #if YDREAM_FOAM == 1
        vec3 foamLight = omniLight + directLightColor * (visibleSky * 0.6) + candleColor * 0.5;
        vec3 foamColor = vec3(0.92, 0.96, 1.0) * clamp(foamLight, vec3(0.05), vec3(1.4));
        refractedColor = mix(refractedColor, foamColor, clamp(foam, 0.0, 1.0) * 0.85);
    #endif

    return refractedColor;
}

vec3 get_normals(vec3 bump, vec3 fragpos) {
    float NdotE = abs(dot(waterNormal, normalize(fragpos)));

    bump *= vec3(NdotE) + vec3(0.0, 0.0, 1.0 - NdotE);

    mat3 tbn_matrix = mat3(
        tangent.x, binormal.x, waterNormal.x,
        tangent.y, binormal.y, waterNormal.y,
        tangent.z, binormal.z, waterNormal.z
    );

    return normalize(bump * tbn_matrix);
}

vec4 reflection_calc(vec3 fragpos, vec3 normal, vec3 reflected, inout float infinite, float dither) {
    #if SSR_TYPE == 0
        #if defined DISTANT_HORIZONS || defined VOXY
            vec3 pos = camera_to_screen(fragpos + reflected * 768.0);
        #else
            vec3 pos = camera_to_screen(fragpos + reflected * 76.0);
        #endif
    #else
        vec3 pos = fastRaymarch(reflected, fragpos, infinite, dither);
    #endif

    float border =
        clamp((1.0 - (max(0.0, abs(pos.y - 0.5)) * 2.0)) * 50.0, 0.0, 1.0);

    border = clamp(border - pow(pos.y, 10.0), 0.0, 1.0);

    pos.x = abs(pos.x);
    if (pos.x > 1.0) {
        pos.x = 1.0 - (pos.x - 1.0);
    }

    #if SSR_TYPE == 0
        float occluder = step(texture2D(depthtex1, clamp(pos.xy, vec2(0.0), vec2(1.0))).r, 0.9999);
        infinite = 1.0 - occluder * clamp(border * 2.0, 0.0, 1.0);
    #endif

    #if SSR_TYPE == 0
        vec2 reflectUV = clamp(pos.xy, vec2(0.002), vec2(0.998));
        vec2 reflectBlur = vec2(pixelSizeX, pixelSizeY) * 2.0;
        vec3 reflectColor = texture2D(gaux1, reflectUV).rgb * 0.36;
        reflectColor += texture2D(gaux1, reflectUV + vec2(reflectBlur.x, 0.0)).rgb * 0.16;
        reflectColor += texture2D(gaux1, reflectUV - vec2(reflectBlur.x, 0.0)).rgb * 0.16;
        reflectColor += texture2D(gaux1, reflectUV + vec2(0.0, reflectBlur.y)).rgb * 0.16;
        reflectColor += texture2D(gaux1, reflectUV - vec2(0.0, reflectBlur.y)).rgb * 0.16;
        return vec4(reflectColor, border);
    #else
        return vec4(texture2D(gaux1, pos.xy).rgb, border);
    #endif
}

vec3 water_shader(
    vec3 fragpos,
    vec3 normal,
    vec3 color,
    vec3 sky_reflect,
    vec3 reflected,
    float fresnel,
    float visibleSky,
    float dither,
    vec3 lightColor
) {
    vec4 reflection = vec4(0.0);
    float infinite = 1.0;

    #if REFLECTION == 1
        if (isEyeInWater == 0) {
            reflection = reflection_calc(fragpos, normal, reflected, infinite, dither);
        }
    #endif

    reflection.rgb = mix(
        sky_reflect * visibleSky,
        reflection.rgb,
        reflection.a
    );

    #ifdef VANILLA_WATER
        fresnel *= 0.8;
    #endif

    #if SUN_REFLECTION == 1
        #ifndef NETHER
            #ifndef THE_END
                return mix(color, reflection.rgb, fresnel * REFLEX_INDEX) +
                    vec3(sun_reflection(reflect(normalize(fragpos), normal))) * lightColor * infinite * visibleSky * float(isEyeInWater == 0);
            #else
                return mix(color, reflection.rgb, fresnel * REFLEX_INDEX);
            #endif
        #else
            return mix(color, reflection.rgb, fresnel * REFLEX_INDEX);
        #endif
    #else
        return mix(color, reflection.rgb, fresnel * REFLEX_INDEX);
    #endif
}

vec4 cristal_reflection_calc(vec3 fragpos, vec3 normal, inout float infinite, float dither) {
    #if SSR_TYPE == 0
        #if defined DISTANT_HORIZONS || defined VOXY
            vec3 reflectedVector = reflect(normalize(fragpos), normal) * 768.0;
        #else
            vec3 reflectedVector = reflect(normalize(fragpos), normal) * 76.0;
        #endif
        vec3 pos = camera_to_screen(fragpos + reflectedVector);
    #else
        vec3 reflectedVector = reflect(normalize(fragpos), normal);
        vec3 pos = fastRaymarch(reflectedVector, fragpos, infinite, dither);

        if (pos.x > 99.0) {
            #if defined DISTANT_HORIZONS
                pos = camera_to_screen(fragpos + reflectedVector * 768.0);
            #else
                pos = camera_to_screen(fragpos + reflectedVector * 76.0);
            #endif
        }
    #endif

    float border_x = max(-fourthPow(abs(2.0 * pos.x - 1.0)) + 1.0, 0.0);
    float border_y = max(-fourthPow(abs(2.0 * pos.y - 1.0)) + 1.0, 0.0);
    float border = min(border_x, border_y);

    return vec4(texture2D(gaux1, pos.xy, 0.0).rgb, border);
}

vec4 cristal_shader(
    vec3 fragpos,
    vec3 normal,
    vec4 color,
    vec3 skyReflectionColor,
    float fresnel,
    float visibleSky,
    float dither,
    vec3 lightColor
) {
    vec4 reflection = vec4(0.0);
    float infinite = 0.0;

    #if REFLECTION == 1
        reflection = cristal_reflection_calc(fragpos, normal, infinite, dither);
    #endif

    skyReflectionColor = mix(color.rgb, skyReflectionColor, visibleSky * visibleSky);

    reflection.rgb = mix(
        skyReflectionColor,
        reflection.rgb,
        reflection.a
    );

    color.rgb = mix(color.rgb, skyReflectionColor, fresnel);
    color.rgb = mix(color.rgb, reflection.rgb, fresnel);

    color.a = mix(color.a, 1.0, fresnel * .9);

    #if SUN_REFLECTION == 1
        #ifndef NETHER
        #ifndef THE_END
            return color + vec4(
                mix(
                    vec3(sun_reflection(reflect(normalize(fragpos), normal)) * lightColor * infinite * visibleSky),
                    vec3(0.0),
                    reflection.a
                ),
                0.0
            );
        #else
            return color;
        #endif
        #else
            return color;
        #endif
    #else
        return color;
    #endif
}
