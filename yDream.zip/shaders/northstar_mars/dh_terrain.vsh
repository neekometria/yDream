#version 120
#extension GL_ARB_shader_texture_lod : enable
#define NORTHSTAR_MARS

#define DH_BLOCK

#include "/common/solid_dh_blocks_vertex.glsl"
