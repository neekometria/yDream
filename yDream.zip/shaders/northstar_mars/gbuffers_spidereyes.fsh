#version 120
#extension GL_ARB_shader_texture_lod : enable

#define GBUFFER_SPIDEREYES
#define NO_SHADOWS

#include "/common/spidereyes_blocks_fragment.glsl"
