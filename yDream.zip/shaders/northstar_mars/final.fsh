#version 120
#extension GL_ARB_shader_texture_lod : enable

#define FINAL_SHADER
#define NO_SHADOWS

#include "/common/final_fragment.glsl"
