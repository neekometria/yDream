#version 120
#extension GL_ARB_shader_texture_lod : enable

#define GBUFFER_TEXTURED

#include "/common/solid_blocks_vertex.glsl"
