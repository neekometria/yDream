#version 120
#extension GL_ARB_shader_texture_lod : enable
#define NORTHSTAR_MERCURY

#define GBUFFER_LINE
#define NO_SHADOWS
#define SHADER_BASIC
#define SHADER_LINE

#include "/common/line_blocks_vertex.glsl"
