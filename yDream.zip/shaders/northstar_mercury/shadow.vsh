#version 120
#extension GL_ARB_shader_texture_lod : enable
#define NORTHSTAR_MERCURY

#define SHADOW_SHADER

#include "/common/shadow_vertex.glsl"
