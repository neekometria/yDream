#version 120
#extension GL_ARB_shader_texture_lod : enable
#define NORTHSTAR_ORBIT_RADIUS 1.52366231
#define NORTHSTAR_ORBIT_MARS
#define NORTHSTAR_ORBIT

#define DH_WATER

#include "/common/solid_dh_water_vertex.glsl"
